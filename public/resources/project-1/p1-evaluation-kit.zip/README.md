# Project 1 public evaluation pack

- `dev_examples.json` — five development prompts with reference continuations, for pipeline sanity checks.
- `tutor_prompts.json` — the ten public tutor-evaluation prompt strings (continuations withheld).
- `separation_validator.py` — run before training to check your corpus for overlap with the released prompts.
- `metrics.py` — reference-token-normalised PPL/BPB, the marks formula, and a repetition-rate check.

Withheld tutor ground truth and any clean reserve cases are never included in this pack.
