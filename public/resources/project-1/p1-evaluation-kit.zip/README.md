# Project 1 public evaluation pack

- `dev_examples.json` — five development prompts with reference continuations, for pipeline sanity checks.
- `separation_validator.py` — run before training to check your corpus for overlap with the released prompts.
- `metrics.py` — reference-token-normalised PPL/BPB, the marks formula, and a repetition-rate check.

## Pending: tutor-evaluation prompts

The ten public tutor-evaluation prompt strings are not included in this pack. They are drawn from
the properly source-separated narrative corpus, which is a teaching-team deliverable that does not
yet exist in this repository (see `docs/ASSIGNMENT_BRIEF.md`'s "Unresolved decisions"). This pack
therefore cannot yet be marked `Available` on the Project 1 page; the resource card states this
dependency and links no fabricated file. No placeholder prompt strings are shipped in their place.

Withheld tutor ground truth and any clean reserve cases are never included in this pack.
