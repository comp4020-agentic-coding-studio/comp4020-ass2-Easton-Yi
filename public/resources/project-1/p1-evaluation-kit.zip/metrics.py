"""Public evaluation utilities: reference-token-normalised PPL/BPB, a simple
repetition-rate check, and (for stories) an end-of-sequence stopping check.
These mirror the official tutor-evaluation calculation at small scale so you
can validate your pipeline before the frozen submission is marked.
"""
import math
from collections import Counter


def reference_token_normalised_ppl(nlls: list[float], ref_token_counts: list[int]) -> float:
    """P = exp(sum(NLL_i) / sum(N_i^ref)) — pooled across all items, per the
    published formula. Continuation-only NLL and reference token
    counts, not full-prompt values."""
    return math.exp(sum(nlls) / sum(ref_token_counts))


def ppl_marks(p: float, max_marks: float) -> float:
    """The shared piecewise PPL-to-marks formula."""
    if p <= 25:
        return max_marks
    if p < 50:
        return max_marks * math.exp(-0.1 * (p - 25))
    return 0.0


def repetition_rate(token_ids: list[int], n: int = 4) -> float:
    """Fraction of n-grams in the generated continuation that repeat an
    earlier n-gram — a cheap degeneration signal."""
    grams = [tuple(token_ids[i : i + n]) for i in range(len(token_ids) - n + 1)]
    if not grams:
        return 0.0
    counts = Counter(grams)
    repeated = sum(c - 1 for c in counts.values() if c > 1)
    return repeated / len(grams)
