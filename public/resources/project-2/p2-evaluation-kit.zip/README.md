# Project 2 behaviour evaluation pack

- `dev_examples.json` — five development openings, each with a genuine reference continuation and style note, for pipeline sanity checks.
- `separation_validator.py` — reused from Project 1; run before post-training on any new data.
- `retention_check.py` — pairs starting-checkpoint and post-trained outputs for regression review.
- `blind_review_rubric.json` — the four task-specific dimensions and weights raters use.

## Pending: tutor-evaluation openings

The ten public tutor-evaluation openings are not included in this pack. They are drawn from the
properly source-separated corpus, which is a teaching-team deliverable that does not yet exist in
this repository. This pack therefore cannot yet be marked `Available` on the Project 2 page; no
placeholder opening strings are shipped in their place.
