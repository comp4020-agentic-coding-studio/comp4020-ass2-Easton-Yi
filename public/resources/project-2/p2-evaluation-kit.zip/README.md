# Project 2 behaviour evaluation pack

- `dev_examples.json` — five development openings with a style note, for pipeline sanity checks.
- `tutor_openings.json` — the ten public tutor openings for blinded review (continuations withheld).
- `separation_validator.py` — reused from Project 1; run before post-training on any new data.
- `retention_check.py` — pairs starting-checkpoint and post-trained outputs for regression review.
- `blind_review_rubric.json` — the four task-specific dimensions and weights raters use.
