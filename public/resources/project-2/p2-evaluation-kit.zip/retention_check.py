"""Compares outputs from the post-trained model and the unchanged starting
checkpoint on the same Project 1 narrative-continuation prompts, to surface
regressions rather than hide them behind one improved metric."""
def retention_report(starting_outputs: list[str], post_trained_outputs: list[str]) -> dict:
    assert len(starting_outputs) == len(post_trained_outputs)
    return {
        "n_compared": len(starting_outputs),
        "pairs": list(zip(starting_outputs, post_trained_outputs)),
    }
