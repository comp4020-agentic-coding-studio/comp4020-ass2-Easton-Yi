"""Checks a training corpus for exact or near-duplicate overlap against the
released evaluation prompts. Run this before training begins.

Usage: python separation_validator.py <corpus.txt> <eval_prompts.json>
"""
import json
import re
import sys


def normalise(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def ngrams(text: str, n: int = 8) -> set[str]:
    words = normalise(text).split()
    return {" ".join(words[i : i + n]) for i in range(max(0, len(words) - n + 1))}


def check(corpus_path: str, prompts_path: str, n: int = 8) -> int:
    with open(corpus_path, encoding="utf-8") as f:
        corpus_ngrams = ngrams(f.read(), n)
    with open(prompts_path, encoding="utf-8") as f:
        prompts = json.load(f)

    hits = 0
    for item in prompts:
        prompt_text = item["prompt"] if isinstance(item, dict) else item
        overlap = ngrams(prompt_text, n) & corpus_ngrams
        if overlap:
            hits += 1
            print(f"contamination risk: {len(overlap)} shared {n}-grams with a held-out prompt")
    if hits == 0:
        print("no exact or near-duplicate overlap detected")
    return hits


if __name__ == "__main__":
    sys.exit(1 if check(sys.argv[1], sys.argv[2]) else 0)
