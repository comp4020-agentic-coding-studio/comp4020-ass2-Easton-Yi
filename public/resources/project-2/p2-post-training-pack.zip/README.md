# Project 2 post-training starter pack

- `p2-colab-starter.ipynb` — loads the starting checkpoint and points at the recipes below.
- `cpt.py` — continued pre-training on the target-style corpus.
- `sft.py` — supervised instruction tuning with response-only loss masking.
- `dpo_toy.py` — a small preference-optimisation exercise (optional extension; establish an SFT baseline first).
