"""Continued pre-training recipe: same objective as Project 1, restarted
from the frozen starting checkpoint on the target-style corpus only."""
def train_cpt(model, target_style_loader, optimizer, steps: int) -> None:
    for step, batch in zip(range(steps), target_style_loader):
        x, y = batch
        logits = model(x)
        loss = _cross_entropy(logits, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()


def _cross_entropy(logits, targets):
    import torch.nn.functional as F
    return F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1))
