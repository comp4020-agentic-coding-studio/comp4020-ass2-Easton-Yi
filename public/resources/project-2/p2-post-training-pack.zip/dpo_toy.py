"""Toy preference-optimisation exercise (DPO-style). Establish an SFT
baseline first — this is an optional extension, not a required step."""
def dpo_loss(logp_chosen, logp_rejected, ref_logp_chosen, ref_logp_rejected, beta: float = 0.1):
    import torch
    pi_logratios = logp_chosen - logp_rejected
    ref_logratios = ref_logp_chosen - ref_logp_rejected
    return -torch.nn.functional.logsigmoid(beta * (pi_logratios - ref_logratios)).mean()
