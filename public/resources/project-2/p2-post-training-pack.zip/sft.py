"""Supervised instruction-tuning recipe with response-only loss masking.
Document your chat/instruction schema and special tokens in the report if
you use this."""
def build_loss_mask(input_ids, response_start_idx: int):
    """1 for response tokens (the ones that receive gradient), 0 for the
    prompt tokens that only provide context."""
    mask = [0] * len(input_ids)
    for i in range(response_start_idx, len(input_ids)):
        mask[i] = 1
    return mask


def masked_cross_entropy(logits, targets, mask):
    import torch
    import torch.nn.functional as F
    per_token = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1), reduction="none")
    mask_t = torch.tensor(mask, dtype=per_token.dtype, device=per_token.device).view(-1)
    return (per_token * mask_t).sum() / mask_t.sum().clamp_min(1)
