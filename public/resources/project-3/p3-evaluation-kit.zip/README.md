# Project 3 track evaluation pack

- `dev_examples_track_a.json` (3 examples) / `dev_examples_track_b.json` (2 examples) — five
  development examples total across both tracks, each with genuine reference/ground truth.
- `separation_validator.py` — reused from Project 1; run before fine-tuning on any new data.
- `track_a_verifier.py` / `track_b_verifier.py` — the automatic constraint/answer checks.
- `regression_utils.py` — shared pre-existing-capability regression comparison.

Students see only the resources for their selected track when this pack is unpacked per the page's
track guidance; the archive ships both so either track's tooling is available offline.

## Pending: tutor-evaluation inputs

The ten public tutor-evaluation inputs are not included in this pack. They are drawn from the
properly source-separated corpus (and, for Track B, the private GitLab repository's `test_pilot`
schema), which is a teaching-team deliverable that does not yet exist in this repository. This pack
therefore cannot yet be marked `Available` on the Project 3 page; no placeholder input strings are
shipped in their place.
