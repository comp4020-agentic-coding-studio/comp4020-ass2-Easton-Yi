# Project 3 track evaluation pack

- `dev_examples_track_a.json` / `dev_examples_track_b.json` — five track-adapted development examples with ground truth (shown here abridged).
- `tutor_inputs.json` — the ten public tutor-evaluation inputs (answers withheld).
- `separation_validator.py` — reused from Project 1; run before fine-tuning on any new data.
- `track_a_verifier.py` / `track_b_verifier.py` — the automatic constraint/answer checks.
- `regression_utils.py` — shared pre-existing-capability regression comparison.

Students see only the resources for their selected track when this pack is unpacked per the page's
track guidance; the archive ships both so either track's tooling is available offline.
