"""Shared regression utilities: compares Project 3 output against the
declared starting checkpoint's output on a monitored pre-existing capability."""
def regression_report(starting_outputs: list[str], final_outputs: list[str]) -> dict:
    assert len(starting_outputs) == len(final_outputs)
    return {"n_compared": len(starting_outputs), "pairs": list(zip(starting_outputs, final_outputs))}
