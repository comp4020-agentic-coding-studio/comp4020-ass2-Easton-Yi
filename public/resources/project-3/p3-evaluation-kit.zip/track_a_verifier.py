"""Automatically checkable Track A constraint metrics — e.g. vocabulary
inclusion, ending-type classification hooks. Extend per your declared task."""
def contains_required_vocabulary(continuation: str, required_words: list[str]) -> bool:
    lowered = continuation.lower()
    return all(word.lower() in lowered for word in required_words)
