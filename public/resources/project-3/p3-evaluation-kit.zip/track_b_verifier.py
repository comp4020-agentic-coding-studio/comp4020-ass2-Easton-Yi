"""Exact-answer and output-format checks for Track B."""
import re

ANSWER_FORMAT = re.compile(r"^-?\d+(\.\d+)?$")


def is_valid_format(answer_text: str) -> bool:
    return bool(ANSWER_FORMAT.match(answer_text.strip()))


def is_exact_match(answer_text: str, reference: str) -> bool:
    return is_valid_format(answer_text) and float(answer_text) == float(reference)
