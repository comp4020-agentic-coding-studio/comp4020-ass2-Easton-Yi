# Project 3 fine-tuning starter pack

- `p3-sft-starter.ipynb` — the shared SFT loop for both tracks.
- `masking_check.py` — verifies response-only loss masking on a formatted example.
- `track_a_examples.json` / `track_b_examples.json` — example task records for each track (illustrative, not the graded set).
- `baseline_commands.md` — commands for the required unchanged-model comparison.
