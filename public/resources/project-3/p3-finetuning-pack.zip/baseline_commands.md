# Baseline comparison commands

Run the unchanged starting checkpoint through the same evaluation harness before training, so the
controlled comparison has a real baseline:

```bash
python evaluate.py --checkpoint starting_checkpoint.pt --eval tutor_inputs.json --out baseline.json
python evaluate.py --checkpoint final_checkpoint.pt --eval tutor_inputs.json --out final.json
python compare.py baseline.json final.json
```
