"""Sanity-checks that only response tokens receive gradient, for either
track's instruction-formatted examples."""
def verify_masking(example: dict) -> bool:
    prompt_len = len(example["prompt_token_ids"])
    total_len = len(example["input_ids"])
    mask = example["loss_mask"]
    assert len(mask) == total_len
    return all(m == 0 for m in mask[:prompt_len]) and any(m == 1 for m in mask[prompt_len:])
