# CVPR-style report template

A compact two-column LaTeX template for the SLOP4225 engineering report, styled after the CVPR
paper format. `main.tex` reproduces the same two-column, Times-based layout using only standard,
freely-redistributable LaTeX packages (`geometry`, `times`, `graphicx`, `hyperref`).

## Upstream source and licence status

This is **not** the official CVPR author kit. The official kit (`cvpr.sty`, `cvpr_eso.sty`) is
maintained at [github.com/cvpr-org/author-kit](https://github.com/cvpr-org/author-kit), but that
repository does not publish an explicit redistribution licence for those class files, so this
course cannot verify it is safe to bundle them here. Until that licence is confirmed, this template
intentionally avoids the real class files and reproduces the same visual layout with standard
packages instead. If the teaching team later confirms a redistribution basis, this archive should
be replaced with the genuine `cvpr.sty`/`cvpr_eso.sty` and this note updated to record the
confirmed source and licence.

## Use

Upload the whole folder to Overleaf, or compile locally with `pdflatex main.tex && bibtex main &&
pdflatex main.tex && pdflatex main.tex`.

## Contents

- `main.tex` — the report skeleton, including the required Engineering Report sections and the
  mandatory AI Assistance Statement heading.
- `references.bib` — a placeholder bibliography entry showing the citation plumbing.

## Licence

Original content for this course; reuse and adapt freely within SLOP4225.
