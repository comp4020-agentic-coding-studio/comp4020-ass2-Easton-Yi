# CVPR-style report template

A compact two-column LaTeX template for the SLOP4225 engineering report, styled after the CVPR
paper format. It intentionally does **not** bundle the proprietary `cvpr.sty`/`cvpr_eso.sty`
class files (those carry their own redistribution terms); instead `main.tex` reproduces the same
two-column, Times-based layout using only standard LaTeX packages (`geometry`, `times`,
`graphicx`, `hyperref`), so it can be redistributed freely with this course.

## Use

Upload the whole folder to Overleaf, or compile locally with `pdflatex main.tex && bibtex main &&
pdflatex main.tex && pdflatex main.tex`.

## Contents

- `main.tex` — the report skeleton, including the required Engineering Report sections and the
  mandatory AI Assistance Statement heading.
- `references.bib` — a placeholder bibliography entry showing the citation plumbing.

## Licence

Original content for this course; reuse and adapt freely within SLOP4225.
